import XCTest
@testable import LifeBook

final class LifeBookTests: XCTestCase {
    
    func testRecordingManagerInit() {
        let manager = RecordingManager()
        XCTAssertFalse(manager.isRecording)
        XCTAssertEqual(manager.currentTranscription, "")
    }
    
    func testAIInterviewerPrompts() {
        let interviewer = AIInterviewer()
        interviewer.generatePrompt()
        XCTAssertNotNil(interviewer.currentPrompt)
    }
    
    func testAccessibilityConfiguration() {
        let accessibilityManager = AccessibilityManager()
        // Test that manager initializes without errors
        XCTAssertNotNil(accessibilityManager)
    }
}
