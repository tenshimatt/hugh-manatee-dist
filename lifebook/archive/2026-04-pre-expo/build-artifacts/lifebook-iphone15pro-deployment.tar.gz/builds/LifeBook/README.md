# Life Book - AI-Guided Memoir Recording App

An iOS application specifically designed for elderly users to record, organize, and preserve their life stories through AI-guided conversations.

## Features

- **One-Touch Recording**: Large, accessible recording button (120pt)
- **Real-Time Transcription**: Speech-to-text with large, readable display
- **AI Conversation Guidance**: Contextual prompts to encourage storytelling
- **Accessibility First**: Full VoiceOver support, large text, high contrast
- **CloudKit Sync**: Secure cloud storage of memoir content
- **Family Sharing**: Share stories with family members

## Technical Requirements

- iOS 15.0+
- Xcode 14+
- Apple Developer Program enrollment
- CloudKit container configuration

## Accessibility Features

- Minimum 64pt touch targets
- Dynamic Type support up to 310% scaling
- VoiceOver compatibility
- High contrast color schemes
- Haptic feedback for interactions

## Privacy & Security

- All recordings stored in private CloudKit container
- Local encryption using iOS Data Protection APIs
- Explicit consent for any sharing features
- No third-party data sharing

## Getting Started

1. Open the project in Xcode
2. Configure CloudKit container: `iCloud.com.tenshimatt.memoirguide`
3. Add required capabilities: Microphone, Speech Recognition, CloudKit
4. Build and run on iOS device (simulator has limited audio features)

## Testing

Run the test suite: `xcodebuild test -scheme LifeBook`

Built following the comprehensive specification in `specs/001-lifebook-mvp/spec.md`
