import Foundation
import AVFoundation
import Speech
import CloudKit
import Combine

@MainActor
class RecordingManager: NSObject, ObservableObject {
    @Published var isRecording = false
    @Published var currentTranscription = ""
    @Published var recordingDuration: TimeInterval = 0
    @Published var storageStatus = "Ready"
    
    private var audioEngine = AVAudioEngine()
    private var speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var audioSession = AVAudioSession.sharedInstance()
    private var recordingTimer: Timer?
    private var autoSaveTimer: Timer?
    
    // CloudKit container - FR-031: Private container
    private let container = CKContainer(identifier: "iCloud.com.tenshimatt.memoirguide")
    private lazy var privateDatabase = container.privateCloudDatabase
    
    // Current session data
    private var currentSessionRecord: CKRecord?
    private var sessionStartTime: Date?
    
    override init() {
        super.init()
        setupAudioSession()
        requestPermissions()
    }
    
    // MARK: - Audio Session Setup
    private func setupAudioSession() {
        do {
            // FR-003: Background recording support
            try audioSession.setCategory(.playAndRecord, 
                                       mode: .measurement, 
                                       options: [.duckOthers, .allowBluetooth])
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("Audio session setup failed: \(error)")
        }
    }
    
    // MARK: - Permissions
    private func requestPermissions() {
        // Request microphone permission
        audioSession.requestRecordPermission { granted in
            Task { @MainActor in
                if !granted {
                    self.storageStatus = "Microphone access denied"
                }
            }
        }
        
        // Request speech recognition permission
        SFSpeechRecognizer.requestAuthorization { authStatus in
            Task { @MainActor in
                switch authStatus {
                case .authorized:
                    self.storageStatus = "Ready"
                case .denied, .restricted, .notDetermined:
                    self.storageStatus = "Speech recognition not authorized"
                @unknown default:
                    self.storageStatus = "Unknown authorization status"
                }
            }
        }
    }
    
    // MARK: - Recording Control
    func startRecording() {
        guard !isRecording else { return }
        
        // Cancel any existing recognition task
        recognitionTask?.cancel()
        recognitionTask = nil
        
        // Create recognition request - FR-004: Real-time transcription
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest = recognitionRequest else { return }
        
        recognitionRequest.shouldReportPartialResults = true
        
        // Start recognition task
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            Task { @MainActor in
                if let result = result {
                    self?.currentTranscription = result.bestTranscription.formattedString
                }
                
                if error != nil || result?.isFinal == true {
                    self?.stopRecording()
                }
            }
        }
        
        // Configure audio engine - FR-008: 44.1kHz/16-bit quality
        let inputNode = audioEngine.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            recognitionRequest.append(buffer)
        }
        
        // Start audio engine
        do {
            audioEngine.prepare()
            try audioEngine.start()
            
            isRecording = true
            sessionStartTime = Date()
            createNewSession()
            startTimers()
            
        } catch {
            print("Audio engine start failed: \(error)")
            storageStatus = "Recording failed to start"
        }
    }
    
    func stopRecording() {
        guard isRecording else { return }
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        
        recognitionTask?.cancel()
        recognitionTask = nil
        
        stopTimers()
        isRecording = false
        
        // FR-002: Final save on stop
        saveSession()
    }
    
    // MARK: - Session Management
    private func createNewSession() {
        // Create CloudKit record for new session
        currentSessionRecord = CKRecord(recordType: "MemoirSession")
        currentSessionRecord?["startTime"] = sessionStartTime as CKRecordValue
        currentSessionRecord?["transcription"] = "" as CKRecordValue
        currentSessionRecord?["duration"] = 0.0 as CKRecordValue
        currentSessionRecord?["deviceInfo"] = UIDevice.current.model as CKRecordValue
    }
    
    // MARK: - Auto-save - FR-002: Every 30 seconds
    private func startTimers() {
        // Recording duration timer
        recordingTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            Task { @MainActor in
                if let startTime = self.sessionStartTime {
                    self.recordingDuration = Date().timeIntervalSince(startTime)
                }
            }
        }
        
        // Auto-save timer - FR-002: Every 30 seconds
        autoSaveTimer = Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { _ in
            Task { @MainActor in
                self.saveSession()
            }
        }
    }
    
    private func stopTimers() {
        recordingTimer?.invalidate()
        autoSaveTimer?.invalidate()
        recordingTimer = nil
        autoSaveTimer = nil
    }
    
    // MARK: - CloudKit Persistence - FR-031, FR-038
    private func saveSession() {
        guard let record = currentSessionRecord else { return }
        
        // Update record with current data
        record["transcription"] = currentTranscription as CKRecordValue
        record["duration"] = recordingDuration as CKRecordValue
        record["lastSaved"] = Date() as CKRecordValue
        
        // Save to CloudKit - FR-038: Automatic sync
        privateDatabase.save(record) { savedRecord, error in
            Task { @MainActor in
                if let error = error {
                    print("CloudKit save failed: \(error)")
                    self.storageStatus = "Sync failed - saved locally"
                    // FR-041: Local backup
                    self.saveLocalBackup()
                } else {
                    self.storageStatus = "Synced to iCloud"
                }
            }
        }
    }
    
    // FR-041: Local backup for 30 days minimum
    private func saveLocalBackup() {
        let documentsPath = FileManager.default.urls(for: .documentDirectory, 
                                                   in: .userDomainMask).first!
        let backupURL = documentsPath.appendingPathComponent("local_backups")
        
        do {
            try FileManager.default.createDirectory(at: backupURL, 
                                                  withIntermediateDirectories: true)
            
            let sessionData = [
                "transcription": currentTranscription,
                "duration": recordingDuration,
                "timestamp": ISO8601DateFormatter().string(from: Date())
            ]
            
            let backupFile = backupURL.appendingPathComponent("session_\(Date().timeIntervalSince1970).json")
            let jsonData = try JSONSerialization.data(withJSONObject: sessionData)
            try jsonData.write(to: backupFile)
            
        } catch {
            print("Local backup failed: \(error)")
        }
    }
    
    // MARK: - Memory Management - FR-055
    deinit {
        stopRecording()
        stopTimers()
    }
}

// MARK: - CloudKit Extensions
extension RecordingManager {
    
    // FR-040: Offline capability
    func syncWhenOnline() {
        // Check for pending local backups and sync when connection available
        let documentsPath = FileManager.default.urls(for: .documentDirectory, 
                                                   in: .userDomainMask).first!
        let backupURL = documentsPath.appendingPathComponent("local_backups")
        
        do {
            let backupFiles = try FileManager.default.contentsOfDirectory(at: backupURL, 
                                                                        includingPropertiesForKeys: nil)
            
            for file in backupFiles where file.pathExtension == "json" {
                // Process and upload local backups
                syncLocalBackup(file)
            }
        } catch {
            print("Sync check failed: \(error)")
        }
    }
    
    private func syncLocalBackup(_ fileURL: URL) {
        // Implementation for syncing local backups to CloudKit
        // This would be called when network connection is restored
    }
}
