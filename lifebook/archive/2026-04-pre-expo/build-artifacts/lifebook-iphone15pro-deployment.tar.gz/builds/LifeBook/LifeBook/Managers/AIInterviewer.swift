import Foundation

class AIInterviewer: ObservableObject {
    @Published var currentPrompt: String?
    
    private let conversationStarters = [
        "Tell me about your earliest childhood memory.",
        "What was your neighborhood like when you were growing up?",
        "Describe your parents and what they were like.",
        "What was school like in your day?",
        "Tell me about your first job.",
        "What was dating like when you were young?",
        "Describe your wedding day.",
        "What was it like when your children were born?",
        "Tell me about a time that changed your life.",
        "What advice would you give to your younger self?"
    ]
    
    func generatePrompt() {
        currentPrompt = conversationStarters.randomElement()
    }
    
    func clearPrompt() {
        currentPrompt = nil
    }
}
