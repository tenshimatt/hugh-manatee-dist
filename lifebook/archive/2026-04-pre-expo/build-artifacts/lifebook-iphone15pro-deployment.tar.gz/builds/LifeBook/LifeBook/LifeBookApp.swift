import SwiftUI
import CloudKit

@main
struct LifeBookApp: App {
    @StateObject private var recordingManager = RecordingManager()
    @StateObject private var aiInterviewer = AIInterviewer()
    @StateObject private var accessibilityManager = AccessibilityManager()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(recordingManager)
                .environmentObject(aiInterviewer)
                .environmentObject(accessibilityManager)
                .preferredColorScheme(.light) // High contrast for elderly users
        }
    }
}
