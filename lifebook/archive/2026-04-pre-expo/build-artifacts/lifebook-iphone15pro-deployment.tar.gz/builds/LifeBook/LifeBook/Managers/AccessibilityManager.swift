import Foundation
import UIKit

class AccessibilityManager: ObservableObject {
    
    func configureForElderlyUsers() {
        // Enable larger text sizes
        UIApplication.shared.preferredContentSizeCategory = .accessibilityExtraExtraExtraLarge
        
        // Increase button hit areas
        UIView.appearance().accessibilityTraits = .button
        
        // Configure VoiceOver settings
        UIAccessibility.post(notification: .screenChanged, argument: nil)
    }
    
    func announceText(_ text: String) {
        UIAccessibility.post(notification: .announcement, argument: text)
    }
}
