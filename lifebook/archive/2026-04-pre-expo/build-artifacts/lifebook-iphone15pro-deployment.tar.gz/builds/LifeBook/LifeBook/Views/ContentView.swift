import SwiftUI
import AVFoundation

struct ContentView: View {
    @EnvironmentObject var recordingManager: RecordingManager
    @EnvironmentObject var aiInterviewer: AIInterviewer
    @EnvironmentObject var accessibilityManager: AccessibilityManager
    
    var body: some View {
        NavigationView {
            VStack(spacing: 32) {
                // Large, accessible title - FR-016 compliance
                Text("Life Book")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    .accessibilityLabel("Life Book - Your Memoir Recording App")
                
                Spacer()
                
                // Main record button - FR-001: 120pt with 64pt touch target
                RecordButton()
                    .frame(width: 120, height: 120)
                    .accessibilityLabel(recordingManager.isRecording ? "Stop recording" : "Start recording")
                    .accessibilityHint("Double tap to start or stop recording your memoir")
                
                // Live transcription display - FR-004
                if recordingManager.isRecording {
                    ScrollView {
                        Text(recordingManager.currentTranscription)
                            .font(.title2) // Large text for elderly users
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                    }
                    .frame(maxHeight: 200)
                    .accessibilityLabel("Live transcription")
                }
                
                // AI conversation prompts - FR-009
                if let prompt = aiInterviewer.currentPrompt {
                    VStack {
                        Text("💭 Conversation Starter")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        
                        Text(prompt)
                            .font(.title3)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    .accessibilityLabel("AI conversation suggestion: \(prompt)")
                }
                
                Spacer()
                
                // Navigation buttons - FR-019: 64pt touch targets
                HStack(spacing: 24) {
                    NavigationLink(destination: LibraryView()) {
                        AccessibleNavButton(icon: "book.fill", text: "My Stories")
                    }
                    .accessibilityLabel("View my recorded stories")
                    
                    NavigationLink(destination: SettingsView()) {
                        AccessibleNavButton(icon: "gear.fill", text: "Settings")
                    }
                    .accessibilityLabel("App settings and preferences")
                }
            }
            .padding()
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear {
            accessibilityManager.configureForElderlyUsers()
        }
    }
}

struct AccessibleNavButton: View {
    let icon: String
    let text: String
    
    var body: some View {
        VStack {
            Image(systemName: icon)
                .font(.title)
            Text(text)
                .font(.caption)
        }
        .frame(minWidth: 80, minHeight: 64) // FR-019: 64pt minimum
        .foregroundColor(.blue)
    }
}

struct RecordButton: View {
    @EnvironmentObject var recordingManager: RecordingManager
    
    var body: some View {
        Button(action: {
            // FR-019: Haptic feedback
            let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
            impactFeedback.impactOccurred()
            
            if recordingManager.isRecording {
                recordingManager.stopRecording()
            } else {
                recordingManager.startRecording()
            }
        }) {
            ZStack {
                Circle()
                    .fill(recordingManager.isRecording ? Color.red : Color.blue)
                    .frame(width: 120, height: 120) // FR-001: 120pt button
                
                Image(systemName: recordingManager.isRecording ? "stop.fill" : "mic.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
            }
        }
        .scaleEffect(recordingManager.isRecording ? 1.1 : 1.0)
        .animation(.easeInOut(duration: 0.2), value: recordingManager.isRecording)
    }
}

// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(RecordingManager())
            .environmentObject(AIInterviewer())
            .environmentObject(AccessibilityManager())
    }
}
