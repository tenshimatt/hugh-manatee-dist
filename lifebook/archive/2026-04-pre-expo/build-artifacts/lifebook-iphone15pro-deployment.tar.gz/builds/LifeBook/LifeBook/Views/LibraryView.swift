import SwiftUI

struct LibraryView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("My Stories")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()
                
                Text("Your recorded memories will appear here")
                    .font(.title2)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Spacer()
            }
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
