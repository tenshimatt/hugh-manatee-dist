#!/bin/bash
set -e

echo "=== Auto Deploy to iPhone 15 Pro ==="

# Function to check if Xcode command line tools are available
check_xcode() {
    if ! command -v xcodebuild &> /dev/null; then
        echo "❌ Xcode command line tools not found"
        echo "💡 This script needs to run on a Mac with Xcode installed"
        echo ""
        echo "To set up on Mac:"
        echo "1. Install Xcode from App Store"
        echo "2. Run: xcode-select --install"
        echo "3. Connect iPhone 15 Pro via USB"
        echo "4. Enable Developer Mode on device"
        return 1
    fi
    return 0
}

# Function to detect iPhone 15 Pro
detect_device() {
    echo "🔍 Scanning for iPhone 15 Pro..."
    
    DEVICE_LIST=$(xcrun devicectl list devices 2>/dev/null || echo "")
    
    if echo "$DEVICE_LIST" | grep -q "iPhone 15 Pro"; then
        DEVICE_ID=$(echo "$DEVICE_LIST" | grep "iPhone 15 Pro" | head -1 | awk '{print $1}')
        echo "✅ Found iPhone 15 Pro: $DEVICE_ID"
        return 0
    else
        echo "❌ iPhone 15 Pro not detected"
        echo ""
        echo "💡 Troubleshooting:"
        echo "   - Connect iPhone 15 Pro via USB cable"
        echo "   - Unlock device and tap 'Trust This Computer'"
        echo "   - Enable Developer Mode: Settings > Privacy & Security > Developer Mode"
        echo "   - Make sure device shows in Xcode (Window > Devices and Simulators)"
        return 1
    fi
}

# Function to set up Apple Developer credentials
setup_credentials() {
    echo "🔐 Setting up Apple Developer credentials..."
    
    if [ -z "$DEVELOPMENT_TEAM" ]; then
        echo "⚠️  DEVELOPMENT_TEAM not set"
        echo ""
        echo "To set your Apple Developer Team ID:"
        echo "1. Get Team ID from https://developer.apple.com/account"
        echo "2. Run: export DEVELOPMENT_TEAM='YOUR_TEAM_ID'"
        echo "3. Or add to your shell profile (.bashrc, .zshrc)"
        echo ""
        echo "For automatic signing, Xcode will detect your team"
        return 1
    fi
    
    echo "✅ Development Team: $DEVELOPMENT_TEAM"
    return 0
}

# Main deployment function
deploy_to_device() {
    echo "🚀 Starting deployment to iPhone 15 Pro..."
    
    # Build for device
    xcodebuild build \
        -project "LifeBook.xcodeproj" \
        -scheme "LifeBook" \
        -destination "id=$DEVICE_ID" \
        -configuration Debug \
        CODE_SIGN_STYLE=Automatic \
        DEVELOPMENT_TEAM="$DEVELOPMENT_TEAM" \
        PRODUCT_BUNDLE_IDENTIFIER="com.tenshimatt.memoirguide" \
        ENABLE_BITCODE=NO \
        ONLY_ACTIVE_ARCH=YES
    
    # Install on device
    xcodebuild install \
        -project "LifeBook.xcodeproj" \
        -scheme "LifeBook" \
        -destination "id=$DEVICE_ID" \
        -configuration Debug
}

# Execute deployment pipeline
main() {
    echo "📱 Life Book - iPhone 15 Pro Auto Deploy"
    echo "=========================================="
    
    # Check prerequisites
    if ! check_xcode; then
        exit 1
    fi
    
    if ! detect_device; then
        exit 1
    fi
    
    if ! setup_credentials; then
        echo "⚠️  Proceeding with automatic code signing..."
    fi
    
    # Deploy
    if deploy_to_device; then
        echo ""
        echo "🎉 SUCCESS: Life Book deployed to iPhone 15 Pro!"
        echo ""
        echo "📱 App Details:"
        echo "   Name: Life Book"
        echo "   Bundle ID: com.tenshimatt.memoirguide"
        echo "   Device: iPhone 15 Pro ($DEVICE_ID)"
        echo "   Features: Audio recording, AI guidance, CloudKit sync"
        echo ""
        echo "🧪 Testing Instructions:"
        echo "   1. Open Life Book app on your iPhone 15 Pro"
        echo "   2. Grant microphone permissions"
        echo "   3. Tap the large blue record button"
        echo "   4. Test voice recording and transcription"
        echo "   5. Verify AI conversation prompts appear"
        echo ""
        echo "✅ Ready for memoir recording testing!"
    else
        echo ""
        echo "❌ Deployment failed"
        echo "💡 Check Xcode for detailed error messages"
        exit 1
    fi
}

# Run main function
main
