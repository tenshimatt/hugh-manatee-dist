#!/bin/bash
set -e

echo "🚀 Building Life Book for iPhone 15 Pro..."

PROJECT_NAME="LifeBook"
SCHEME="LifeBook"
BUNDLE_ID="com.tenshimatt.memoirguide"

# Detect connected iPhone 15 Pro
DEVICE_ID=$(xcrun devicectl list devices | grep "iPhone 15 Pro" | head -1 | awk '{print $1}' || echo "")

if [ -z "$DEVICE_ID" ]; then
    echo "❌ iPhone 15 Pro not detected. Please connect your device."
    echo "💡 Make sure:"
    echo "   - iPhone 15 Pro is connected via USB"
    echo "   - Device is unlocked and trusted"
    echo "   - Developer mode is enabled in Settings > Privacy & Security"
    exit 1
fi

echo "📱 Detected iPhone 15 Pro: $DEVICE_ID"

# Clean and build
echo "🧹 Cleaning previous builds..."
xcodebuild clean -project "$PROJECT_NAME.xcodeproj" -scheme "$SCHEME"

echo "🔨 Building for device..."
xcodebuild build -project "$PROJECT_NAME.xcodeproj" \
    -scheme "$SCHEME" \
    -destination "id=$DEVICE_ID" \
    -configuration Debug \
    CODE_SIGN_STYLE=Automatic \
    DEVELOPMENT_TEAM="$DEVELOPMENT_TEAM" \
    PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID"

# Install on device
echo "📱 Installing on iPhone 15 Pro..."
xcodebuild install -project "$PROJECT_NAME.xcodeproj" \
    -scheme "$SCHEME" \
    -destination "id=$DEVICE_ID" \
    -configuration Debug

echo ""
echo "✅ Life Book successfully deployed to iPhone 15 Pro!"
echo ""
echo "📱 App installed and ready for testing"
echo "🔧 Build configuration: Debug"
echo "📦 Bundle ID: $BUNDLE_ID"
echo "🆔 Device ID: $DEVICE_ID"
echo ""
echo "🎉 Ready to test memoir recording with AI guidance!"
