import SwiftUI
import AVFoundation

struct ContentView: View {
    @EnvironmentObject var recordingManager: RecordingManager
    @EnvironmentObject var aiInterviewer: AIInterviewer
    @EnvironmentObject var accessibilityManager: AccessibilityManager
    
    var body: some View {
        NavigationView {
            VStack(spacing: 32) {
                // Large, accessible title
                Text("Life Book")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                    .accessibilityLabel("Life Book - Your Memoir Recording App")
                
                Spacer()
                
                // Main record button - 120pt as per spec
                RecordButton()
                    .frame(width: 120, height: 120)
                    .accessibilityLabel(recordingManager.isRecording ? "Stop recording" : "Start recording")
                    .accessibilityHint("Double tap to start or stop recording your memoir")
                
                // Live transcription display
                if recordingManager.isRecording {
                    ScrollView {
                        Text(recordingManager.currentTranscription)
                            .font(.title2) // Large text for elderly users
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(12)
                    }
                    .frame(maxHeight: 200)
                    .accessibilityLabel("Live transcription")
                }
                
                // AI conversation prompts
                if let prompt = aiInterviewer.currentPrompt {
                    VStack {
                        Text("💭 Conversation Starter")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        
                        Text(prompt)
                            .font(.title3)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.blue.opacity(0.1))
                            .cornerRadius(12)
                    }
                    .padding(.horizontal)
                    .accessibilityLabel("AI conversation suggestion: \(prompt)")
                }
                
                Spacer()
                
                // Navigation buttons
                HStack(spacing: 24) {
                    NavigationLink(destination: LibraryView()) {
                        VStack {
                            Image(systemName: "book.fill")
                                .font(.title)
                            Text("My Stories")
                                .font(.caption)
                        }
                        .frame(minWidth: 80, minHeight: 64) // 64pt touch target
                        .foregroundColor(.blue)
                    }
                    .accessibilityLabel("View my recorded stories")
                    
                    NavigationLink(destination: SettingsView()) {
                        VStack {
                            Image(systemName: "gear.fill")
                                .font(.title)
                            Text("Settings")
                                .font(.caption)
                        }
                        .frame(minWidth: 80, minHeight: 64)
                        .foregroundColor(.blue)
                    }
                    .accessibilityLabel("App settings and preferences")
                }
            }
            .padding()
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear {
            accessibilityManager.configureForElderlyUsers()
        }
    }
}

struct RecordButton: View {
    @EnvironmentObject var recordingManager: RecordingManager
    
    var body: some View {
        Button(action: {
            if recordingManager.isRecording {
                recordingManager.stopRecording()
            } else {
                recordingManager.startRecording()
            }
        }) {
            ZStack {
                Circle()
                    .fill(recordingManager.isRecording ? Color.red : Color.blue)
                    .frame(width: 120, height: 120)
                
                Image(systemName: recordingManager.isRecording ? "stop.fill" : "mic.fill")
                    .font(.system(size: 40))
                    .foregroundColor(.white)
            }
        }
        .scaleEffect(recordingManager.isRecording ? 1.1 : 1.0)
        .animation(.easeInOut(duration: 0.2), value: recordingManager.isRecording)
    }
}
