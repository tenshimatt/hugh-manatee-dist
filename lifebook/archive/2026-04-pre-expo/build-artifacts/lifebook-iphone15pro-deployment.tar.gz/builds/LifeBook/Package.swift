// swift-tools-version: 5.8
import PackageDescription

let package = Package(
    name: "LifeBook",
    platforms: [.iOS(.v15)],
    products: [
        .library(name: "LifeBook", targets: ["LifeBook"]),
    ],
    dependencies: [
        .package(url: "https://github.com/apple/swift-collections.git", from: "1.0.0"),
    ],
    targets: [
        .target(
            name: "LifeBook",
            dependencies: [
                .product(name: "Collections", package: "swift-collections"),
            ],
            resources: [.process("Resources")]
        ),
        .testTarget(
            name: "LifeBookTests",
            dependencies: ["LifeBook"]
        ),
    ]
)
